package client_package;

import java.io.Serializable;

public class Employee implements Serializable{

	public Employee(String firstname, String lastname, int age) {
		// TODO Auto-generated constructor stub
	}

}
